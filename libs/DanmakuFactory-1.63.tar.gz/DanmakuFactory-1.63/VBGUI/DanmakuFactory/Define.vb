﻿Public Module Define
    Public Const cliVersion As String = "1.62"
    Public Const guiVersion As String = "1.62"
    Public Const guiVersionText As String = "1.62GUI Release(210902)"
    Public Const cliProgramFileName As String = "DF_REL1.62CLI.exe"
End Module
